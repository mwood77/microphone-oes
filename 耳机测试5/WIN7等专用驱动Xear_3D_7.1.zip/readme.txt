In this folder (updated on 2009-11-19):

CMedia CM6206 Xear 3D 7.1 channel USB Audio Driver & Application

[\Xear 3D 7.1\Windows 7\setup.exe]
   Windows 7 32-bit/64-bit driver version 2.0.1.4

[\Xear 3D 7.1\setup.exe]
   Windows driver version 1.1.26. Supports:
   Windows Vista 32/64-bit 
   Windows XP 32/64-bit 
   Windows 2000 
   Windows Server 2008 32/64-bit
   Windows Server 2003 32/64-bit


---END OF FILE---





